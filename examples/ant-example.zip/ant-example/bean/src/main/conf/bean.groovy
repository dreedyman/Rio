deployment(name:'Hello World Example') {
    groups 'rio'

    service(name: 'Hello',
            type: 'fixed',
            //fork: 'no',
            //jvmArgs: '-Xms8m -Xmx2000m -Dfoo=bar',
            //environment: 'DYLD_LIBRARY_PATH=${RIO_HOME}/brlcad'
            ) {
        interfaces {
            classes 'bean.Hello'
            resources 'bean/lib/bean-dl.jar'
        }
        implementation(class: 'bean.service.HelloImpl') {
            resources 'bean/lib/bean.jar'
        }

        parameters {
            parameter name: "food", value: "fries"
        }
        maintain 1

        configuration '''
            bean {
                food = "fries";    
            }'''            
    }
}
